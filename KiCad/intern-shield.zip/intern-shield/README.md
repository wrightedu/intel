# KiCad instructions

![circuit cheatsheet](../img/circuit-schematic-cheatsheet.png)

## Notes

- The Jameco 7-Segment display *LS-5161AS* is Common Cathode and has an identical footprint and pinout as the KiCad *Display_7Segment:D1X8K*
- we are using a custom footprint for this device that has larger diameter holes so that we can use a M-F header pin for the 7 Segment display
- So far this still needs code...
